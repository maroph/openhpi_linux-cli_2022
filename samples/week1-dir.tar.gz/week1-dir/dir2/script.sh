#!/bin/bash

echo UGluZ3VpbmUgc2luZCBsdXN0aWdlIFRpZXJlCg== | base64 -d
